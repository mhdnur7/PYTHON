while True: # تبدأ حلقة التكرار من هنا
    print("\n--- Hesap Makinesi ---")
    print('1. toplama\n2. cikarma\n3. çarpma\n4. bölme\n0. çıkmak')
    
    işlem = int(input("Seçiminizi yapın: ")) # استقبال الاختيار

    # شرط الخروج من البرنامج
    if işlem == 0:
        print("Programdan çıkılıyor... Hoşça kalın!")
        break # كسر الحلقة وإيقاف البرنامج فوراً

    # إذا لم يختر 0، نطلب الأرقام لإجراء العملية
    num1 = float(input("Enter first number: "))
    num2 = float(input("Enter second number: "))

    if işlem == 1:
        toplama = num1 + num2
        print('toplama :', toplama)

    elif işlem == 2:
        cikarma = num1 - num2
        print('cikarma :', cikarma)

    elif işlem == 3:
        carpma = num1 * num2
        print('çarpma :', carpma)

    elif işlem == 4:
        if num2 != 0:
            bolme = num1 / num2
            print('bölme :', bolme)
        else:
            print('hata: sıfıra bölünemezsin !')
    else:
        print("Geçersiz seçim! Lütfen tekrar deneyin.")